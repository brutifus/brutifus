from .brutifus import * # So that users only need to do import brutus
from .brutifus_metadata import __version__
