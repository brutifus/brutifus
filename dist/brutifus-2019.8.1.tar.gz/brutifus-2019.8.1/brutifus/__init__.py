#from .brutifus import * # So that users only need to do import brutifus
from .brutifus_version import __version__ # Gives users easy access to the version
